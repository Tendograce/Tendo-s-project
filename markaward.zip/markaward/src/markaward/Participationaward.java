package markaward;
import java.util.Scanner;
public class Participationaward {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner(System.in);
		int mark;
		System.out.println("Enter mark:");
		mark=input.nextInt();
		for(int i=49; i==mark; ++mark) {
			System.out.println(++mark);
		}
	}

}
